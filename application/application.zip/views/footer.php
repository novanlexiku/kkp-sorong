				<section id="footer" class="page-section">
					<footer id="footer-section" class="page-section pt-30 pb-30 center-xs">					
						<div class="copyright fw300 mb-sm-10"><span>&copy; Portal Website KKP-Sorong<?php echo date('Y');?> </span></div>
						<!-- ACROLL TO TOP-->	
						<div class="top-button"><h5>Top</h5><div class="line"></div></div>
					</footer>
				</section>